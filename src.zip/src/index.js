import React from 'react';
import Menu from './Menu'
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
ReactDOM.render(
  <>
  <Menu/>
  <br/>
  <br/>
  <App/>
  <br/>
  <center><h4>Creater : Prabhat Mishra || Email : prabhatm580@gmail.com</h4></center>
  </>,
  document.getElementById('root')
);