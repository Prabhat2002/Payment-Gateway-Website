import React from 'react';
import './menu.css'
function Menu() {
    return (
        <>
            <div className="h1">
                <p>The Spark Foundation</p>
                    <span>Home</span>
                    <span>About</span>
                    <span>Services</span>
                    <span>Contact-us</span>
        </div>
        </>
            );
}
            export default Menu;